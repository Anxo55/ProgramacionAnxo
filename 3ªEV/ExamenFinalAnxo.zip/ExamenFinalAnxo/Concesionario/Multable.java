public interface Multable {

    public int MULTA_MAXIMA=100;
    public String Multa(int cantidad);
    public String disminuirMulta(int cantidad);
    public String aumentarMulta(int cantidad);
    
}
